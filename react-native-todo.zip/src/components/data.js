const Gamedata = [
    { id: 1, item: 'image1', status: false },
    { id: 2, item: 'image2', status: false },
    { id: 3, item: 'image3', status: false },
    { id: 4, item: 'image4', status: false },
    { id: 5, item: 'image5', status: false },
    { id: 6, item: 'image6', status: false },
    { id: 7, item: 'image7', status: false },
    { id: 8, item: 'image8', status: false },
];

export default Gamedata