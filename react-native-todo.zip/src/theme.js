export const theme = {
  background: '#ffffff',
  itemBackground: '#313131',
  main: '#778bdd',
  text: '#cfcfcf',
  done: '#616161',
  BLACK: "#262626",
  PURPLE: "#7A5FD9",
  VIOLET: "#6A66F2",
  BLUE: "#5EADF2",
  GREEN: "#35F2BD",

};
