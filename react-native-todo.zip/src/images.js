import image1 from '../assets/icons/apple.png';
import image2 from '../assets/icons/facebook.png';
import image3 from '../assets/icons/github.png';
import image4 from '../assets/icons/google.png';
import image5 from '../assets/icons/instagram.png';
import image6 from '../assets/icons/tik-tok.png';
import image7 from '../assets/icons/twitter.png';
import image8 from '../assets/icons/youtube.png';


export const images = {
  image1: image1,
  image2: image2,
  image3: image3,
  image4: image4,
  image5: image5,
  image6: image6,
  image7: image7,
  image8: image8,
};
