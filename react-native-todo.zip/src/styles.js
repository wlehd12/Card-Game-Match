import { StyleSheet, Dimensions } from 'react-native';

export const commonStyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    backgroundColor: 'black',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    flex: 1,
    backgroundColor: 'gray',
    padding: 10,
    marginHorizontal: 5,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  section: {
    flex: 1,
    justifyContent: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: 'gray',
    padding: 8,
    color: 'white',
    width: Dimensions.get('window').width * 0.8,
  },
  footer: {
    justifyContent: 'center',
  },
  footerButton: {
    backgroundColor: 'gray',
    padding: 10,
    borderRadius: 5,
  },
  resultContainer: {
    marginTop: 16,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  resultText: {
    color: 'black',
  },
});